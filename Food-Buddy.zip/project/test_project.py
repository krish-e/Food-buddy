from project import greet_user, get_course, budgetter, print_in_table
from tabulate import tabulate

restaurants = [
    {"Name": "KFC", "Rating": "4/5", "Phone": "8938249382", "Cuisines": ["american", "indian"], "Cost for 2": "500"},
    {"Name": "Taco Bell", "Rating": "3.5/5", "Phone": "9847384928", "Cuisines": ["american", "mexican"], "Cost for 2": "600"},
    {"Name": "Anandha Bhavan", "Rating": "4/5", "Phone": "7382718293", "Cuisines": ["south indian"], "Cost for 2": "300"}
]

def test_greet_user():
    assert greet_user(25) == None
    assert greet_user(8) == "\nGood Morning!"
    assert greet_user(16) == "\nGood Afternoon!"
    assert greet_user(20) == "\nGood Evening!"


def test_get_course():
    assert get_course(10) == "breakfast"
    assert get_course(14) == "lunch"
    assert get_course(23) == "dinner"
    assert get_course(103) == None


def test_budgetter():
    assert budgetter(restaurants, 200) == [{"Name": "Anandha Bhavan", "Rating": "4/5", "Phone": "7382718293", "Cuisines": ["south indian"], "Cost for 2": "300"}]
    assert budgetter(restaurants, 10) == []
    assert budgetter(restaurants, 1000) == restaurants


def test_print_in_table():
    headers = restaurants[0].keys()
    rows = [restaurant.values() for restaurant in restaurants]
    assert print_in_table(restaurants) == tabulate(rows, headers, tablefmt="grid")

    rows = [restaurant.values() for restaurant in restaurants[1:]]
    assert print_in_table(restaurants[1:]) == tabulate(rows, headers, tablefmt="grid")